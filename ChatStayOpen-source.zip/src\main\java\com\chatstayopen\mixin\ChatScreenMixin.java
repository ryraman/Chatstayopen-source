package com.chatstayopen.mixin;

import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ChatScreen.class)
public abstract class ChatScreenMixin extends Screen {
    @Shadow protected TextFieldWidget chatField;
    @Shadow protected String originalChatText;

    @Shadow abstract void sendMessage(String chatText, boolean addToHistory);
    @Shadow abstract void setChatFromHistory(int offset);

    protected ChatScreenMixin(Text title) {
        super(title);
    }

    /**
     * Handle ENTER ourselves: send exactly once, clear the field, keep the screen open.
     * Every other key (ESC, arrows, TAB, ...) falls through to vanilla untouched.
     */
    @Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
    private void chatstayopen$keepOpen(KeyInput input, CallbackInfoReturnable<Boolean> cir) {
        int key = input.key();
        if (key != 257 && key != 335) { // GLFW_KEY_ENTER / GLFW_KEY_KP_ENTER
            return;
        }

        String text = this.chatField.getText();
        this.sendMessage(text, true);

        // If a command/message handler swapped the screen (e.g. a command opened a GUI), respect it.
        if (this.client == null || this.client.currentScreen != (Object) this) {
            cir.setReturnValue(true);
            return;
        }

        // Reset history navigation to "end of history" and clear the input.
        this.originalChatText = "";
        this.setChatFromHistory(1_000_000);
        this.chatField.setText("");
        this.chatField.setFocused(true);
        this.setFocused(this.chatField);
        cir.setReturnValue(true);
    }
}
